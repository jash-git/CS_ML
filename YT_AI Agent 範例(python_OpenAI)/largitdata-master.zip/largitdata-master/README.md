## 大數軟體(LargitData) X 大數學堂 

### 網站連結
- https://www.largitdata.com/
- https://www.largitdata.com/courses/

### Youtube 頻道
- https://www.youtube.com/channel/UCFdTiwvDjyc62DBWrlYDtlQ

### Facebook 粉絲頁
- https://www.facebook.com/largitdata/

### InfoLite 下載連結
- https://chrome.google.com/webstore/detail/infolite/ipjbadabbpedegielkhgpiekdlmfpgal

### InfoMiner 產品簡介
- http://www.largitdata.com/infominer/ 

### Anaconda 下載連結
- https://www.continuum.io/downloads

###  人人都爱数据科学家！Python数据科学精华实战课程

- https://edu.hellobi.com/course/159

### 手把手教你用Python 实践深度学习 

- https://edu.hellobi.com/course/278
