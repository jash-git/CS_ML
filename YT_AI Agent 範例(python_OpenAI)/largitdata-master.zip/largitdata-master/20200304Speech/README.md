## DeepLearning 101
- https://github.com/ywchiu/largitdata/blob/master/20200304Speech/Deep_Learning_101.ipynb

## DeepFaceLab
- https://github.com/iperov/DeepFaceLab

## DeepFaceLab Workspace
- https://drive.google.com/drive/folders/11EyQelvxnIfyZt-Qqx3Nppxw4rbY2ThC?usp=sharing
- https://drive.google.com/open?id=1-MH0eS6UhV11RvlilkVH5Cl6tA3n41mZ
- https://drive.google.com/open?id=1tjgHKOYK1cOHRVD8IqKemxGOEv9dY94x
- https://drive.google.com/open?id=1RfrsMMLxG1Ko2lJfHwc2mNLmSyE9M0RG

## DeepFakes Example
- https://largitdata.com/course/123/
